function beta_h=beta_h(v)

beta_h=1./(exp(-(v+33)/10)+1);