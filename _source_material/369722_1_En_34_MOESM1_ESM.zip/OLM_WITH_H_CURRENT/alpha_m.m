function alpha_m=alpha_m(v)
q=(v+38)/10;
alpha_m=q./(1-exp(-q));

