function beta_m=beta_m(v)
beta_m=4*exp(-(v+65)/18);