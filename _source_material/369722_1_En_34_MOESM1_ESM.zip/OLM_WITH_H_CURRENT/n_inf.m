function n_inf=n_inf(v);
n_inf=alpha_n(v)./(alpha_n(v)+beta_n(v));