function m_inf=m_inf(v);
m_inf=alpha_m(v)./(alpha_m(v)+beta_m(v));