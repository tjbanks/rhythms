function n_o_inf=n_o_inf(v);
n_o_inf=alpha_n_o(v)./(alpha_n_o(v)+beta_n_o(v));