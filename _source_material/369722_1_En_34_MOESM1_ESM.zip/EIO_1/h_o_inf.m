function h_o_inf=h_o_inf(v);
h_o_inf=alpha_h_o(v)./(alpha_h_o(v)+beta_h_o(v));