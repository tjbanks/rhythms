function beta_h_o=beta_h_o(v)

beta_h_o=1./(exp(-(v+33)/10)+1);