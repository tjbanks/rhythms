function b_o_inf=b_o_inf(v)

b_o_inf=1./(1+exp((v+71)/7.3));