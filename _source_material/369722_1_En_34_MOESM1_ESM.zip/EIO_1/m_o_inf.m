function m_o_inf=m_o_inf(v);
m_o_inf=alpha_m_o(v)./(alpha_m_o(v)+beta_m_o(v));