function alpha_m_o=alpha_m_o(v)
q=(v+38)/10;
alpha_m_o=q./(1-exp(-q));

