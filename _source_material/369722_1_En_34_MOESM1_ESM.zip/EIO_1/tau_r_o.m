function tau_r_o=tau_r_o(v);

tau_r_o=1./(exp(-14.59-0.086*v)+exp(-1.87+0.0701*v));

