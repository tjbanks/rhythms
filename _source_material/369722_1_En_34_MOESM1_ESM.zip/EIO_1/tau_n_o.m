function tau_n_o=tau_n_o(v)
tau_n_o=1./(alpha_n_o(v)+beta_n_o(v));
