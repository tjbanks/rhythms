function alpha_h_o=alpha_h_o(v)

alpha_h_o=0.07*exp(-(v+63)/20);