function tau_h_o=tau_h_o(v)
tau_h_o=1./(alpha_h_o(v)+beta_h_o(v));
