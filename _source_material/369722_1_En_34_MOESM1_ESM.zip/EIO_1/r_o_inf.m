function r_o_inf=r_o_inf(v)

r_o_inf=1./(1+exp((v+84)/10.2));
