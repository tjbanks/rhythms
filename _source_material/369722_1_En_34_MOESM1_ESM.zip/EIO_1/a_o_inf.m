function a_o_inf=a_o_inf(v)

a_o_inf=1./(1+exp(-(v+14)/16.6));