function tau_a_o=tau_a_o(v)

tau_a_o=5;