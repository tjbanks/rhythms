function beta_m_o=beta_m_o(v)
beta_m_o=4*exp(-(v+65)/18);