function tau_m=tau_m(v);
tau_m=1./(alpha_m(v)+beta_m(v));