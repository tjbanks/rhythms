function tau_a=tau_a(v)

tau_a=5;