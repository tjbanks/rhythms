function a_inf=a_inf(v)

a_inf=1./(1+exp(-(v+14)/16.6));