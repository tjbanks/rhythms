function b_inf=b_inf(v)

b_inf=1./(1+exp((v+71)/7.3));